const formatMessage = require('format-message');

export default [
    {
        text: formatMessage({
            id: '1',
            default: '1 (min)',
            description: '1'
        }),
        value: '1'
    },
    {
        text: formatMessage({
            id: '2',
            default: '2',
            description: '2'
        }),
        value: '2'
    },
    {
        text: formatMessage({
            id: '3',
            default: '3',
            description: '3'
        }),
        value: '3'
    },
    {
        text: formatMessage({
            id: '4',
            default: '4',
            description: '4'
        }),
        value: '4'
    },
    {
        text: formatMessage({
            id: '5',
            default: '5',
            description: '5'
        }),
        value: '5'
    },
    {
        text: formatMessage({
            id: '6',
            default: '6',
            description: '6'
        }),
        value: '6'
    },
    {
        text: formatMessage({
            id: '7',
            default: '7',
            description: '7'
        }),
        value: '7'
    },
    {
        text: formatMessage({
            id: '8',
            default: '8',
            description: '8'
        }),
        value: '8'
    },
    {
        text: formatMessage({
            id: '9',
            default: '9',
            description: '9'
        }),
        value: '9'
    },
    {
        text: formatMessage({
            id: '10',
            default: '10',
            description: '10'
        }),
        value: '10'
    },
    {
        text: formatMessage({
            id: '11',
            default: '11',
            description: '11'
        }),
        value: '11'
    },
    {
        text: formatMessage({
            id: '12',
            default: '12',
            description: '12'
        }),
        value: '12'
    },
    {
        text: formatMessage({
            id: '13',
            default: '13',
            description: '13'
        }),
        value: '13'
    },
    {
        text: formatMessage({
            id: '14',
            default: '14',
            description: '14'
        }),
        value: '14'
    },
    {
        text: formatMessage({
            id: '15',
            default: '15',
            description: '15'
        }),
        value: '15'
    },
    {
        text: formatMessage({
            id: '16',
            default: '16',
            description: '16'
        }),
        value: '16'
    },
    {
        text: formatMessage({
            id: '17',
            default: '17',
            description: '17'
        }),
        value: '17'
    },
    {
        text: formatMessage({
            id: '18',
            default: '18',
            description: '18'
        }),
        value: '18'
    },
    {
        text: formatMessage({
            id: '19',
            default: '19',
            description: '19'
        }),
        value: '19'
    },
    {
        text: formatMessage({
            id: '20',
            default: '20',
            description: '20'
        }),
        value: '20'
    },
    {
        text: formatMessage({
            id: '21',
            default: '21',
            description: '21'
        }),
        value: '21'
    },
    {
        text: formatMessage({
            id: '22',
            default: '22',
            description: '22'
        }),
        value: '22'
    },
    {
        text: formatMessage({
            id: '23',
            default: '23',
            description: '23'
        }),
        value: '23'
    },
    {
        text: formatMessage({
            id: '24',
            default: '24',
            description: '24'
        }),
        value: '24'
    },
    {
        text: formatMessage({
            id: '25',
            default: '25',
            description: '25'
        }),
        value: '25'
    },
    {
        text: formatMessage({
            id: '26',
            default: '26',
            description: '26'
        }),
        value: '26'
    },
    {
        text: formatMessage({
            id: '27',
            default: '27',
            description: '27'
        }),
        value: '27'
    },
    {
        text: formatMessage({
            id: '28',
            default: '28',
            description: '28'
        }),
        value: '28'
    },
    {
        text: formatMessage({
            id: '29',
            default: '29',
            description: '29'
        }),
        value: '29'
    },
    {
        text: formatMessage({
            id: '30',
            default: '30',
            description: '30'
        }),
        value: '30'
    },
    {
        text: formatMessage({
            id: '31',
            default: '31',
            description: '31'
        }),
        value: '31'
    },
    {
        text: formatMessage({
            id: '32',
            default: '32',
            description: '32'
        }),
        value: '32'
    },
    {
        text: formatMessage({
            id: '33',
            default: '33',
            description: '33'
        }),
        value: '33'
    },
    {
        text: formatMessage({
            id: '34',
            default: '34',
            description: '34'
        }),
        value: '34'
    },
    {
        text: formatMessage({
            id: '35',
            default: '35',
            description: '35'
        }),
        value: '35'
    },
    {
        text: formatMessage({
            id: '36',
            default: '36',
            description: '36'
        }),
        value: '36'
    },
    {
        text: formatMessage({
            id: '37',
            default: '37',
            description: '37'
        }),
        value: '37'
    },
    {
        text: formatMessage({
            id: '38',
            default: '38',
            description: '38'
        }),
        value: '38'
    },
    {
        text: formatMessage({
            id: '39',
            default: '39',
            description: '39'
        }),
        value: '39'
    },
    {
        text: formatMessage({
            id: '40',
            default: '40',
            description: '40'
        }),
        value: '40'
    },
    {
        text: formatMessage({
            id: '41',
            default: '41',
            description: '41'
        }),
        value: '41'
    },
    {
        text: formatMessage({
            id: '42',
            default: '42',
            description: '42'
        }),
        value: '42'
    },
    {
        text: formatMessage({
            id: '43',
            default: '43',
            description: '43'
        }),
        value: '43'
    },
    {
        text: formatMessage({
            id: '44',
            default: '44',
            description: '44'
        }),
        value: '44'
    },
    {
        text: formatMessage({
            id: '45',
            default: '45',
            description: '45'
        }),
        value: '45'
    },
    {
        text: formatMessage({
            id: '46',
            default: '46',
            description: '46'
        }),
        value: '46'
    },
    {
        text: formatMessage({
            id: '47',
            default: '47',
            description: '47'
        }),
        value: '47'
    },
    {
        text: formatMessage({
            id: '48',
            default: '48',
            description: '48'
        }),
        value: '48'
    },
    {
        text: formatMessage({
            id: '49',
            default: '49',
            description: '49'
        }),
        value: '49'
    },
    {
        text: formatMessage({
            id: '50',
            default: '50',
            description: '50'
        }),
        value: '50'
    },
    {
        text: formatMessage({
            id: '51',
            default: '51',
            description: '51'
        }),
        value: '51'
    },
    {
        text: formatMessage({
            id: '52',
            default: '52',
            description: '52'
        }),
        value: '52'
    },
    {
        text: formatMessage({
            id: '53',
            default: '53',
            description: '53'
        }),
        value: '53'
    },
    {
        text: formatMessage({
            id: '54',
            default: '54',
            description: '54'
        }),
        value: '54'
    },
    {
        text: formatMessage({
            id: '55',
            default: '55',
            description: '55'
        }),
        value: '55'
    },
    {
        text: formatMessage({
            id: '56',
            default: '56',
            description: '56'
        }),
        value: '56'
    },
    {
        text: formatMessage({
            id: '57',
            default: '57',
            description: '57'
        }),
        value: '57'
    },
    {
        text: formatMessage({
            id: '58',
            default: '58',
            description: '58'
        }),
        value: '58'
    },
    {
        text: formatMessage({
            id: '59',
            default: '59',
            description: '59'
        }),
        value: '59'
    },
    {
        text: formatMessage({
            id: '60',
            default: '60',
            description: '60'
        }),
        value: '60'
    },
    {
        text: formatMessage({
            id: '61',
            default: '61',
            description: '61'
        }),
        value: '61'
    },
    {
        text: formatMessage({
            id: '62',
            default: '62',
            description: '62'
        }),
        value: '62'
    },
    {
        text: formatMessage({
            id: '63',
            default: '63',
            description: '63'
        }),
        value: '63'
    },
    {
        text: formatMessage({
            id: '64',
            default: '64',
            description: '64'
        }),
        value: '64'
    },
    {
        text: formatMessage({
            id: '65',
            default: '65 (max)',
            description: '65'
        }),
        value: '65'
    }
];
