<div align="center">

![QuakeFragment logo](/extensions/QuakeStudio/assets/BetterQuake.png "BetterQuake Logo") 

# Better Quake

</div>

BetterQuake is an extension made for [Gandi IDE](https://getgandi.com/) to fully allow the use of custom shaders.
This extension is built with an [extension scaffholding](https://github.com/FurryR/scratch-ext) by FurryR. Huge thanks to him :3s

## For contributers and reviewers

Please visit https://github.com/QuakeStudio/BetterQuake. The files provided here are NOT meant to be edited nor viewed, thank you.

---

<div align="center">

_`This project is licensed under the MPL-2.0 license.`_

🐢❤️

</div>
