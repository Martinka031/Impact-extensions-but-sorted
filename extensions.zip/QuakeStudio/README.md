<div align="center">

![QuakeFragment logo](/extensions/QuakeStudio/assets/QuakeStudio.png "QuakeStudio Logo") 

# Quake Studio

</div>

Quake Studio is created specifically to make rendering and WebGL related extensions for [Gandi IDE](https://getgandi.com/).

Visit [our GitHub](https://github.com/QuakeStudio/) for more info.
