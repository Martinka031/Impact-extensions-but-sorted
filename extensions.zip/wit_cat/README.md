文件助手扩展使用了来自 [js-base64](https://github.com/dankogai/js-base64) 的代码 (js-base64 使用 [BSD 3-Clause 协议](https://github.com/dankogai/js-base64/blob/main/LICENSE.md))
