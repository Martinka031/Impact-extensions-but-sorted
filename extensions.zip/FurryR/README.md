# FurryR 的插件仓库

目前包含的插件:

- not.js (MIT): [GitHub](https://github.com/FurryR/not.js)
- lpp (MIT): [GitHub](https://github.com/FurryR/lpp-scratch)

---

_所有插件均遵循源仓库的开源协议开源。_
